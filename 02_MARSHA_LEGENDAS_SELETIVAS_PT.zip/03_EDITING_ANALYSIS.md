# 03 — Análise da edição: Marsha e Clayton em português

Revisão final: as duas versões foram renderizadas, decodificadas integralmente e passaram nas verificações técnicas e na inspeção visual das 76 amostras de páginas de legenda. A transferência pública é verificada separadamente depois do empacotamento.

## Escopo e duração

Foram analisados os 23 arquivos novos desta entrega. Todos entram na ordem numérica 01 → 23. As duas versões apresentam o mesmo episódio único completo: A com legendas completas em português e B com legendas seletivas em português nas falas importantes. A decisão atual do usuário define vozes e legendas em português, substituindo a preferência por inglês do briefing de referência.

| Métrica | Novas fontes recebidas | Montagem aprovada |
|---|---:|---:|
| Duração de imagem | 177,791667 s / 02:57,792 | 162,833333 s / 02:42,833 |
| Quadros | 4267 | 3908 |
| Cadência | 24 fps | 24 fps |
| Tempo retirado | — | 359 quadros / 14,958333 s |
| Fontes representadas | 23 | Todas as 23, sem omissões integrais |

Não há duplicatas exatas entre os arquivos ou os payloads dos vídeos principais deste conjunto. As cenas 20 e 21 são diferentes e ambas permanecem. As reduções vêm somente de aberturas, sobras, reações repetitivas e do cartão final. Nenhum corte foi herdado da edição em inglês. O relatório 04 contém todos os intervalos exatos.

## Achados técnicos e de conteúdo

Os 23 arquivos foram identificados por SHA256, examinados com FFprobe e decodificados integralmente. Todos usam 24 fps. As fontes 01 e 07 têm, respectivamente, 720 × 1280 e 704 × 1280; as outras 21 têm 1080 × 1920. Nas fontes 01 e 07, somente o vídeo H.264 real é usado; a capa JPEG anexada não entra no filme.

A fonte 01 já é 9:16. Seu separador branco móvel entre os quadros nativos 49 e 66 pertence a um wipe incorporado ao vídeo. Ele foi preservado com a imagem inteira; um recorte estático não eliminaria essa transição e removeria conteúdo. A fonte 07 é ligeiramente mais estreita que 9:16 e recebeu o recorte mínimo 702 × 1248, x0/y16, seguido de ampliação proporcional. O enquadramento foi revisto quanto a rosto e mão. A ampliação dessas fontes não cria detalhe nativo 1080p.

As fontes menores 01 e 07 indicam BT709. As demais indicam matriz SMPTE170M, transferência sRGB e primárias BT709; os valores são convertidos efetivamente para BT709 na exportação, sem apenas trocar a etiqueta de cor.

Nos testes completos das fontes, não houve preto ou congelamento indevido em 01–22 nos limiares registrados. A fonte 23 é o cartão original CONTINUA..., com texto branco centralizado e brilho sobre preto. Foram mantidos os quadros 18 → 48, final exclusivo: 1,25 s do texto já legível. O cartão reenviado foi conferido no anexo atual; sua identidade com um cartão anterior não autoriza reutilizar outros arquivos.

A fonte 01 é especialmente alta, aproximadamente −9,24 LUFS, enquanto 21 chega a +0,04 dBTP. As fontes 07 e 23 são muito quietas, aproximadamente −42,54 e −54,01 LUFS, respectivamente, e não foram tratadas como falas a elevar automaticamente. A fonte 07 contém choro não verbal; 23 não contém fala validada. As caudas AAC audíveis de fala ou respiração precisam permanecer protegidas nas transições.

## Ritmo e narrativa

| Intervalo de saída | Conteúdo observado e decisão |
|---|---|
| 00:00–00:03 | Confronto e pedido de dinheiro/comida desde o início. Manter a fala rápida e a transição já gravada, sem introdução gráfica. |
| 00:03–00:08 | Rejeição de Clayton e afirmação de não ter dinheiro. As repetições efetivamente pronunciadas permanecem. |
| 00:08–00:15 | Reação e contradição sobre dinheiro para beber. A versão seletiva privilegia uma ocorrência que oferece mais tempo natural de leitura. |
| 00:15–00:31,625 | Escalada da discussão e pedido para alimentar as crianças; encurtar apenas as sobras após respostas e gestos completos. |
| 00:31,625–00:51,042 | Abandono, oração e choro; preservar a interpretação, com 4,5 s do close não verbal de 07. |
| 00:51,042–01:39,417 | Fotografia, escrita, decisão, saída, busca por emprego e entrega do cartão. Manter punho erguido, passagem pela porta e entrega completos. |
| 01:39,417–02:10,250 | Ostentação no bar e confronto de Jessica; preservar o áudio pouco claro onde existe, sem adivinhar palavras. |
| 02:10,250–02:33,625 | Relato à mãe, cartão, abraço, porta abrindo e retorno de Clayton; 20 e 21 acrescentam acontecimentos distintos. |
| 02:33,625–02:41,583 | Expulsão e reação final com três personagens, sem cortar a tomada final curta. |
| 02:41,583–02:42,833 | Cartão CONTINUA... original, sem palavras novas. |

A edição permanece em velocidade 1,0×, com cortes diretos motivados. Os planos nativos já fornecem closes, reações e mudanças de enquadramento. Não foram criados rostos, roupas, movimentos ou acontecimentos para corrigir a narrativa.

## Idioma, som e legendas

As falas portuguesas nativas são preservadas. A única fonte com diálogo inglês verificado é 18. Para cumprir o alvo português confirmado, apenas suas duas falas receberam novas vozes sintéticas genéricas em português brasileiro, sem clonar os intérpretes: “Minha mãe não te banca mais!” e “Não se mete, garota!”. As frases foram geradas a 1,0× e conferidas por novo reconhecimento automático; não houve regeneração de lábios ou de imagem. O timbre desse trecho é o de vozes genéricas, não o dos atores originais.

Nos trechos pouco claros de 15, 0,608–1,856 s, e 17, 6,240–7,232 s, o usuário autorizou o marcador [fala pouco clara] em A. O áudio nativo permanece. B seleciona apenas frases claras. A transcrição preserva as formas identificadas nos recortes revisados, inclusive peculiaridades de gramática ou vocativo, em vez de inventar correção fluente.

A trilha reutiliza os módulos instrumentais originais da série Marsha, com licença documentada e arranjo novo para esta EDL. Não são seis novas composições. O AAC final mede −18,91 LUFS, −1,75 dBTP e LRA 9,00 LU; não foi limitado para forçar a referência nominal de −16 LUFS. A trilha de piano em 07 recebeu nível moderado próprio para a pausa não verbal, mantendo o ganho do áudio nativo desse trecho em 0 dB. O relatório 05 detalha arranjo, automação e licença.

## Limites documentados

As fontes têm pequenas variações de roupa, barra da blusa e cabelo na sequência 19–22. Foram preservadas como conteúdo já gravado, sem alteração artificial de pessoas. A transição branca de 01 também continua visível por fazer parte do material fornecido.

A reexportação H.264 e a ampliação das fontes menores não são matematicamente sem perdas. Os originais são preservados. O desempenho de A e B só pode ser avaliado com dados de publicação; nenhum estilo de legenda, trilha ou corte garante viralização ou retenção. As verificações e os limites reais dos MP4s estão registrados abaixo.


## Exportações e verificações executadas

| Arquivo | Tamanho do MP4 | Imagem | Áudio |
|---|---:|---|---|
| `01_MARSHA_LEGENDAS_COMPLETAS_PT.mp4` | 95.621.178 bytes | 1080 × 1920, H.264, 24 fps, BT709; 3908 quadros | AAC estéreo, 48 kHz, idioma por; 162,833333 s |
| `02_MARSHA_LEGENDAS_SELETIVAS_PT.mp4` | 95.623.196 bytes | Mesmo plano narrativo, grafo de imagem, duração e cadência | Os mesmos 7634 pacotes AAC de A e da mixagem aprovada |

As duas exportações foram codificadas diretamente das novas fontes, em uma geração H.264, CRF 18/preset slow, com teto VBV de 4500 kb/s para o pacote de download. O teto pode restringir a qualidade em trechos complexos; não torna a codificação sem perdas. A trilha AAC aprovada foi copiada sem nova codificação. O relógio de contêiner em 48 kHz preserva a duração exata de 7.816.000 amostras por canal.

Ambos os filmes passaram na decodificação integral, com 3908 quadros e sem duplicação ou descarte no export. Não foram detectados intervalos pretos indevidos ou congelamentos narrativos inesperados nos testes registrados. O congelamento detectado entre aproximadamente 02:41,583 e 02:42,792 pertence ao cartão original CONTINUA... e é intencional. A comparação integral dos 7634 pacotes AAC, inclusive payloads e tempos, confirmou identidade com a mixagem aprovada e entre A/B. O AAC efetivo mantém −18,91 LUFS e −1,75 dBTP.

A comparação A/B executada confirmou mesmo plano narrativo, grafo de imagem, número de quadros, duração, resolução, cadência e áudio. A diferença planejada está na estratégia, no tamanho e nos ajustes pontuais de posição das legendas. As conclusões sobre vozes usam comparação de PCM, cobertura de transcrição, reconhecimento novo da dublagem e identidade dos pacotes AAC; não são uma alegação de audição humana integral.

Seis quadros de A foram comparados com referências das novas fontes após a mesma conversão de cor e recorte. Os pares de detalhe de 600 × 600 pixels foram examinados em escala 1:1. Na região superior sem legendas, o SSIM das seis amostras variou de 0,958435 a 0,973886, média 0,965198. Há suavização moderada de textura de pele/cabelo, compatível com a codificação limitada e com perdas. Nessas amostras, não houve bloqueio material, mudança relevante de cor, desvio de enquadramento ou perda de expressão que justificasse nova exportação. A medida se refere somente a seis amostras de A e não certifica todos os quadros ou ausência matemática de perdas.

A abertura efetivamente codificada e o cartão final foram conferidos. Todas as 76 páginas de legenda dos MP4s finais tiveram um quadro representativo examinado, reunido em dez pranchas: 57 de A e 19 de B. Leitura, posição inferior e relação com rostos e objetos importantes foram aprovadas nessas amostras, incluindo caderno/mãos em 08 e cartão em 14. Os dois marcadores autorizados aparecem em A e não em B; as duas falas de 18 estão legendadas em português. Nenhuma inspeção por amostras equivale à revisão humana contínua de todos os movimentos do episódio.

SHA256 dos MP4s finais:

- A: `a28b00b5d420c8552e26d33c77abb3c5db63abb73191878654978a188ae6dfd8`.
- B: `06545e6b29561baec720c5715d0731dee6f0d0f83d89fca2dd1d69d1d1b9a5ce`.

Cada ZIP inclui o respectivo MP4 e os quatro relatórios. A transferência pública completa, o CRC do ZIP e os hashes de todos os arquivos internos são verificados depois da publicação e registrados fora dos próprios relatórios, evitando uma dependência circular de hashes.
