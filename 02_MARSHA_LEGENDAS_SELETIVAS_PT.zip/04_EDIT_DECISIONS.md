# 04 — Decisões de montagem em português

EDL desta entrega: 3908 quadros a 24 fps, 162,833333 s. Todas as 23 fontes novas entram na ordem numérica. A e B apresentam o mesmo episódio, cortes e áudio; a estratégia de legenda muda.

Os tempos abaixo usam minutos:segundos.milissegundos, arredondados para apresentação. Os quadros são a referência exata: início incluído, fim exclusivo. O relógio de fonte reinicia em cada arquivo; o relógio de saída pertence ao episódio único.

| Fonte | Intervalo mantido na fonte | Quadros mantidos | Intervalo na saída | Retirado: quadros / tempo | Motivo |
|---|---|---|---|---:|---|
| 01 | 00:00.000–00:09.000 | 0→216 | 00:00.000–00:09.000 | 25 / 1.042 s | Encurtar somente a cauda repetitiva depois das falas e da reação; preservar o wipe nativo e a imagem inteira. |
| 02 | 00:00.000–00:07.958 | 0→191 | 00:09.000–00:16.958 | 0 / 0.000 s | Manter a troca completa e a repetição realmente pronunciada. |
| 03 | 00:00.000–00:07.333 | 0→176 | 00:16.958–00:24.292 | 15 / 0.625 s | Encurtar a sobra depois da resposta e da reação de baixar o olhar. |
| 04 | 00:00.000–00:07.333 | 0→176 | 00:24.292–00:31.625 | 15 / 0.625 s | Encurtar a cauda depois da resposta e do gesto completo de cobrir o rosto. |
| 05 | 00:00.000–00:07.917 | 0→190 | 00:31.625–00:39.542 | 0 / 0.000 s | Preservar abandono, apelo tardio e mão estendida; esta fonte tem 190 quadros. |
| 06 | 00:00.000–00:07.000 | 0→168 | 00:39.542–00:46.542 | 23 / 0.958 s | Encurtar a sobra depois da oração e da reação com a mão na boca. |
| 07 | 00:00.000–00:04.500 | 0→108 | 00:46.542–00:51.042 | 37 / 1.542 s | Preservar 4,5 s de choro não verbal; encurtar a repetição depois do gesto completo. |
| 08 | 00:00.000–00:07.958 | 0→191 | 00:51.042–00:59.000 | 0 / 0.000 s | Preservar fotografia, escrita e decisão com o punho erguido. |
| 09 | 00:00.000–00:07.958 | 0→191 | 00:59.000–01:06.958 | 0 / 0.000 s | Preservar preparação da bolsa e travessia completa da porta. |
| 10 | 00:02.000–00:07.958 | 48→191 | 01:06.958–01:12.917 | 48 / 2.000 s | Começar no corte nativo para a sala lateral; preservar caminhada e fala. |
| 11 | 00:02.000–00:07.958 | 48→191 | 01:12.917–01:18.875 | 48 / 2.000 s | Começar no corte nativo para a mão na porta do restaurante; preservar entrada e pedido. |
| 12 | 00:00.500–00:07.083 | 12→170 | 01:18.875–01:25.458 | 33 / 1.375 s | Encurtar a espera inicial com proteção antes da fala; manter a súplica e mais de 1 s da reação da senhora. |
| 13 | 00:01.000–00:07.958 | 24→191 | 01:25.458–01:32.417 | 24 / 1.000 s | Encurtar a espera sentada; preservar o movimento de levantar e todas as falas, inclusive sua cauda de áudio. |
| 14 | 00:00.000–00:07.000 | 0→168 | 01:32.417–01:39.417 | 12 / 0.500 s | Encerrar depois da entrega do cartão e do gesto completo de levá-lo ao peito. |
| 15 | 00:00.000–00:07.958 | 0→191 | 01:39.417–01:47.375 | 0 / 0.000 s | Preservar áudio pouco claro, ostentação, pergunta e tomada final completa. |
| 16 | 00:01.000–00:07.958 | 24→191 | 01:47.375–01:54.333 | 24 / 1.000 s | Encurtar a aproximação inicial; preservar confronto e movimento de levantar. |
| 17 | 00:00.000–00:07.958 | 0→191 | 01:54.333–02:02.292 | 0 / 0.000 s | Preservar confronto, intervenções e trecho final pouco claro. |
| 18 | 00:00.000–00:07.958 | 0→191 | 02:02.292–02:10.250 | 0 / 0.000 s | Preservar imagem e duração; substituir apenas duas falas inglesas por dublagem portuguesa fiel. |
| 19 | 00:00.000–00:07.958 | 0→191 | 02:10.250–02:18.208 | 0 / 0.000 s | Preservar entrada, relato e reação final de Marsha. |
| 20 | 00:00.000–00:07.958 | 0→191 | 02:18.208–02:26.167 | 0 / 0.000 s | Preservar cena exclusiva de cartão, abraço e porta abrindo. |
| 21 | 00:00.500–00:07.958 | 12→191 | 02:26.167–02:33.625 | 12 / 0.500 s | Encurtar espera inicial; preservar retorno, recusa e repetição falada. É uma cena diferente de 20. |
| 22 | 00:00.000–00:07.958 | 0→191 | 02:33.625–02:41.583 | 0 / 0.000 s | Preservar expulsão e reação final com três personagens. |
| 23 | 00:00.750–00:02.000 | 18→48 | 02:41.583–02:42.833 | 43 / 1.792 s | Preservar o cartão CONTINUA... já legível por 1,25 s; retirar entrada lenta e excesso de duração. |

Total retirado: 359 quadros / 14,958333 s. Nenhuma fonte foi omitida integralmente. 20 e 21 são cenas exclusivas diferentes e permanecem; a omissão de um arquivo usada em outra edição não foi aplicada aqui.

## Decisões transversais

- Preservar velocidade 1,0× e 24 fps nativos, sem interpolação ou aceleração de diálogos.
- Preservar repetições realmente pronunciadas. A seleção B pode não escrever toda repetição, mas não elimina o áudio nem a imagem correspondente.
- Manter gestos e ações completos: mão estendida em 05, fotografia e punho em 08, travessia da porta em 09, entrada em 11, movimento de levantar em 13/16, cartão e abraço em 20 e plano final com três personagens em 22.
- Preservar o wipe móvel original de 01 com a imagem inteira. Corrigir somente a proporção ligeiramente estreita de 07 com recorte 702 × 1248, x0/y16, sem esticar a pessoa.
- Converter tecnicamente as fontes necessárias para BT709, mantendo rostos visíveis e sem escurecimento ou zoom decorativo.
- Preservar as vozes portuguesas existentes. Em 18, substituir somente as duas falas inglesas verificadas pelas novas falas portuguesas autorizadas, com timbre genérico e sem clonagem.
- Manter o áudio nativo dos dois trechos pouco claros e usar [fala pouco clara] na versão A, conforme autorizado. Não preencher lacunas com frases inventadas.
- Preservar o cartão CONTINUA... do anexo atual por 1,25 s, sem tradução ou palavras adicionais.

## Controle

Cada região da EDL guarda o hash de sua nova fonte. As falas e as caudas de áudio orientam os cortes; uma sugestão visual não foi aplicada se cortaria a repetição final de 21. O enquadramento de 07 e as bordas de ação foram revistos nas novas imagens.

As duas exportações e a decodificação integral passaram. A comparação A/B confirmou 3908 quadros, duração, grafo narrativo e todos os 7634 pacotes AAC idênticos. Não há preto indevido ou congelamento narrativo inesperado nos testes registrados; o cartão final congelado é intencional. O relatório 03 contém os resultados e hashes reais dos MP4s. A revisão visual dos 76 quadros representativos de páginas de legenda nos MP4s finais também passou, além da abertura e do cartão original. Esse controle por amostras não equivale à inspeção humana de todos os quadros ou à audição integral.
