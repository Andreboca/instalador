# 05 — Trilha e mixagem da edição portuguesa

Os seis módulos instrumentais originais da série Marsha foram reutilizados com um arranjo novo, vinculado às novas fontes e à EDL portuguesa. Não são seis novas composições. Nenhum vídeo, voz de um episódio anterior, música comercial, áudio de Claire ou Luminous Resolution foi reaproveitado nesta trilha.

A mixagem final desta edição foi executada e seu AAC medido. O áudio das duas exportações foi conferido por comparação integral de pacotes e medição, conforme detalhado abaixo. Duração: 162,833333 s, correspondentes a 7.816.000 amostras de apresentação por canal a 48 kHz e 3908 quadros a 24 fps.

## Arranjo executado

Os tempos usam minutos:segundos.milissegundos, arredondados para apresentação. Os módulos só se sobrepõem nas transições indicadas; não reiniciam a cada arquivo.

| Módulo | Intervalo na saída | Trecho usado do módulo | Fade de entrada / saída | Função narrativa |
|---|---|---|---|---|
| `01_injustice_tension` | 00:00.000–00:47.142 | 00:00.000–00:47.142 | 0.45 s / 0.60 s | Discussão financeira e abandono: piano/cordas baixas com tensão contida. |
| `02_sadness_piano` | 00:46.542–01:13.517 | 00:00.000–00:26.975 | 0.60 s / 0.60 s | Choro, fotografia, decisão e saída: piano esparso. |
| `03_hope_opportunity` | 01:12.917–01:40.017 | 00:00.000–00:27.100 | 0.60 s / 0.60 s | Busca por trabalho e oferta de ajuda: calor moderado. |
| `04_confrontation_pulse` | 01:39.417–02:10.850 | 00:00.000–00:31.433 | 0.60 s / 0.60 s | Bar e confronto de Jessica: pulso baixo e pressão discreta. |
| `05_decision_resolve` | 02:10.250–02:32.433 | 00:00.000–00:22.183 | 0.60 s / 0.60 s | Relato, cartão, abraço, suspense da porta e recusa do apoio financeiro. |
| `06_cliffhanger_unresolved` | 02:31.833–02:42.833 | 00:08.000–00:19.000 | 0.60 s / 0.00 s | Expulsão, reação e cartão final: harmonia suspensa com cauda natural. |

As mudanças musicais usam crossfades de 0,6 s. A primeira entrada dura 0,45 s, sem retardar a imagem ou a fala. O último módulo utiliza seu trecho 8–19 s, com decaimento natural para o cartão original. Não foram adicionados impactos ou whooshes decorativos.

## Automação e vozes

Durante fala/VAD, a trilha usa ganho de −17 dB em relação aos arquivos dos módulos; entre falas, −8 dB, antes do ganho comum final de +1,18 dB. A diferença é um ducking de 9 dB, não uma alegação de que a música fica sempre 17 dB abaixo da voz. A automação utiliza antecipação de 100 ms, proteção de saída de 220 ms e suavização de 50 ms. Durante o choro não verbal de 07, o piano usa ganho próprio de −13 dB em relação ao módulo, com transições suaves. Esse nível sustenta a pausa emocional sem tratar o ruído nativo como voz; o áudio original de 07 permanece com ganho de 0 dB antes do ganho comum final.

As falas portuguesas nativas recebem apenas ganho estático por fonte e ganho comum final, sem mudança de tom ou velocidade. Não foram aplicados EQ, redução de ruído, compressor, limitador ou time-stretch. Fades curtos de borda são usados somente onde não há fala protegida. A montagem preserva caudas audíveis e sincronização; 07 e 23 não são elevadas automaticamente como se fossem diálogos de nível normal.

Somente 18 recebeu duas novas falas pt-BR, com vozes sintéticas genéricas pf_dora e pm_santa, sem clonagem: “Minha mãe não te banca mais!” e “Não se mete, garota!”. O relógio de legenda vem dos fonemas efetivamente gerados, com novo reconhecimento de confirmação. O inglês original não fica por baixo das vozes: ganho zero de 0 a 4,08 s da fonte, transição até 4,12 s e ambiente nativo posterior preservado. Não foi criada outra fala, não houve regeneração de lábios e os demais trechos portugueses mantêm seus intérpretes originais.

## Medição do AAC final real

| Medida | Resultado |
|---|---:|
| Formato | AAC estéreo, 48 kHz, 192 kb/s |
| Duração de apresentação | 162,833333 s |
| Loudness integrada | −18,91 LUFS |
| Pico verdadeiro | −1,75 dBTP |
| LRA | 9,00 LU |
| Teto de pico verificado | Abaixo de −1,00 dBTP |

A loudness ficou abaixo da referência inicial de −16 LUFS para preservar transientes e dinâmica sem comprimir ou limitar as vozes. São medidas do AAC efetivamente exportado. Os campos de saída simulada do medidor não representam um processamento aplicado ao arquivo. A e B usam esse mesmo AAC, copiado sem nova codificação para os MP4s. Os 7634 pacotes AAC, payloads e tempos são idênticos à mixagem aprovada nas duas versões; a duração e os níveis medidos também foram confirmados na decodificação integral dos exports.

SHA256 do AAC comum: `ec2d039efad740c1ccafb27e8896573bc524621be7ffd19e5e62afa6038b8d60`.

## Composição e licença

A partitura original de Marsha utiliza piano, cordas, violoncelo e pizzicato, renderizados com FluidSynth e GeneralUser GS v2.0.3. O manifesto desta edição identifica explicitamente a reutilização dessa composição e o novo arranjo. A licença do instrumento permite gravações musicais privadas ou comerciais, com as qualificações de procedência preservadas no texto integral. Isso não equivale a uma auditoria independente da titularidade de cada amostra ou a garantia contra reivindicações automáticas de plataforma.

A música não contém vozes ou narração. O material de composição, a licença, os módulos e os manifests do novo arranjo estão preservados. As vozes TTS de 18 têm comprovação de geração e tempos separada da procedência da música. A conferência de forma de onda compara os interiores dos trechos nativos com o PCM original multiplicado pelo respectivo ganho estático: a diferença máxima registrada é zero antes da trilha e do ganho comum. A fonte 18 é a exceção documentada de substituição por português. Em 406 janelas de 200 ms dentro dos núcleos de fala, a voz fica 17,03 dB acima da música na mediana e 9,35 dB no percentil 10; a medida não é uma garantia universal de inteligibilidade. A relação é medida nas falas, não no trecho não verbal de 07. A identidade dos 7634 pacotes AAC nos dois MP4s foi confirmada contra a mixagem aprovada, inclusive payloads e tempos. Nenhuma medição garante alcance ou retenção.
