# 06 — Comparação das legendas em português

A e B apresentam o mesmo episódio completo desta entrega: 162,833333 s, 3908 quadros a 24 fps, com vozes em português. As legendas foram compiladas a partir das novas fontes. Os MP4s finais passaram nas verificações técnicas e na revisão visual de um quadro representativo de cada uma das 76 páginas codificadas. Os números abaixo são dos manifests desta composição, não de outro episódio.

| Característica | A — Legendas completas | B — Legendas seletivas |
|---|---|---|
| Texto | Todas as falas portuguesas inteligíveis verificadas e os dois marcadores autorizados. | Somente falas claras de acusação, ameaça, revelação, decisão ou virada emocional. |
| Idioma | Português brasileiro. | Português brasileiro. |
| Áudio | Português nativo, com duas falas genéricas novas apenas em 18. | Exatamente a mesma mixagem de A. |
| Fonte compilada | Montserrat ExtraBold, 84 unidades na composição 1080 × 1920. | Mesma família, 96 unidades. |
| Páginas | 57 | 19 páginas para 18 falas selecionadas. |
| Tempo programado com texto | 89,063 s / 54,70% do episódio. | 32,184 s / 19,76% do episódio. |
| Largura máxima medida de linha | 745,87 px | 716,00 px |
| Limite de largura adotado | 760 px | 760 px |
| Apresentação | Uma ou duas linhas, branco, contorno/sombra escura e poucos destaques dourados. | Mesmo contraste, texto um pouco maior e menos tempo total de legendas. |
| Posição | Região inferior central segura, ajustada quando rostos, mãos ou objetos exigirem. | A mesma região segura; sem legenda no topo. |
| Objetivo de comparação | Compreensão de todas as falas, inclusive sem som. | Dar presença às falas decisivas com mais intervalos sem texto. |

## Fidelidade à fonte atual

Os tempos são derivados das novas fontes. O deslocamento da EDL é aplicado uma única vez ao converter o relógio local de cada clipe para a composição final. As repetições realmente pronunciadas permanecem em A e no áudio de ambas. As fontes 20 e 21 são diferentes e ambas têm conteúdo legendado.

O manifesto relaciona 263 índices de transcrição: 259 índices lexicais claros, incluindo os dez novos de 18, e quatro índices incertos representados pelos dois marcadores autorizados. A versão A cobre essa estratégia completa uma vez, sem transformar hipóteses incertas do reconhecimento automático em palavras escritas. Esse controle verifica a relação entre transcrição e legenda; não garante que o reconhecimento automático seja infalível.

A versão A usa [fala pouco clara] nos intervalos autorizados de 15, 0,608–1,856 s, e 17, 6,240–7,232 s. O áudio original desses trechos não é substituído por uma frase adivinhada. B não seleciona esses marcadores. 07 e 23 não recebem falas inventadas: são, respectivamente, choro não verbal e cartão sem fala validada.

Os nomes próprios podem receber a grafia do projeto, como Clayton, sem modificar o som. Formas coloquiais ou peculiaridades identificadas nos recortes revisados permanecem. Em 19, o vocativo “Filho” foi mantido após revisões focadas; em 20, a construção “por meus filhos” foi preservada, sem trocar silenciosamente a gramática da fonte.

## Duas falas de 18

A nova fonte 18 tinha inglês. Para cumprir o pedido atual de vozes portuguesas, suas duas falas foram traduzidas e geradas em pt-BR com timbres genéricos, sem clonar atores:

- “Minha mãe não te banca mais!”
- “Não se mete, garota!”

O sincronismo das legendas segue os tempos fonéticos das falas TTS realmente adotadas, não os índices das palavras inglesas removidas. O reconhecimento novo da montagem confirmou a sequência lexical em português sem forçar o idioma. Não se promete reprodução da identidade vocal ou sincronismo labial perfeito; a imagem original foi preservada.

## Leitura e limites da comparação

Frases longas devem ser divididas em limites de palavras, sem reduzir silenciosamente a fonte ou prolongar texto sobre uma pausa apenas para caber. As primeiras falas de 01 são rápidas na própria fonte: a transcrição completa conserva esse ritmo, enquanto B pode escolher a repetição posterior com mais duração natural. Não acelerar ou desacelerar a voz para aumentar tempo de leitura sem autorização. A primeira repetição rápida de 01 dura 0,880 s e chega a aproximadamente 32,95 caracteres por segundo; é uma limitação real de leitura do material original. B utiliza a segunda ocorrência, naturalmente mais longa, sem retirar a primeira do áudio.

Na versão B, a frase de 15 foi dividida em duas páginas no limite real da palavra: “A Marsha vai ter que” / “continuar me bancando.”. As demais falas selecionadas incluem comida das crianças, dinheiro para beber, fome, abandono, decisão de procurar uma saída, luta pelos filhos, rejeição e oferta de emprego, confronto de Jessica, recusa de sustento e expulsão. A fonte maior foi mantida; não houve redução silenciosa para acomodar texto longo.

As posições programadas são inferiores e centrais, principalmente x540/y1545. Em A, 08-02 usa y1300 e 14-02/14-03 usam y1400 para evitar a região de escrita/mãos e do cartão nas amostras correspondentes; B também usa y1300 em 08-02. A prévia de um quadro real de fonte por página, com a mesma geometria/cor/ASS, foi examinada para todas as 57 páginas de A e 19 de B; leitura e posição foram aprovadas nessa etapa. A conferência posterior de um quadro representativo de cada página nos MP4s finais aprovou esses ajustes e a relação com rostos, caderno/mãos e cartão nas amostras revisadas. Nenhuma legenda foi programada no topo. A entrada sutil do texto passa de 96% para 100% de escala em aproximadamente 80 ms, sem saltos repetidos.

A auditoria dos 76 eventos ASS verificou ausência de sobreposição e conversão única dos tempos. O arredondamento máximo é de 5 ms contra o JSON e 5,34 ms contra o relógio exato da EDL; isso não implica resolução de imagem superior aos quadros de vídeo a 24 fps. As caudas revisadas podem chegar a 366 ms após o último índice de palavra estimado pelo ASR, acompanhando o decaimento de voz/VAD, sem acrescentar permanência arbitrária para leitura.

O tempo com texto é a soma dos intervalos programados e não mede atenção ou retenção. A largura foi verificada pelo compilador com a fonte adotada; a revisão visual dos MP4s complementou essa medição.

Depois da exportação, foram examinados os 76 quadros representativos das páginas em dez pranchas: A1–A7 e B1–B3. A leitura e a posição inferior foram aprovadas nessas amostras; os marcadores autorizados aparecem somente em A e as duas falas de 18 estão em português. A abertura e o cartão original também foram conferidos. Testes automáticos e inspeção por amostras não são uma alegação de revisão humana contínua de todos os quadros ou de audição integral.

A comparação técnica A/B executada confirmou o mesmo plano narrativo, grafo de imagem, resolução 1080 × 1920, duração 162,833333 s, 3908 quadros a 24 fps e todos os 7634 pacotes AAC idênticos. Os payloads e tempos também coincidem com a mixagem aprovada. As duas decodificações integrais passaram. Nenhuma das duas estratégias é apresentada como garantia de viralização ou retenção. Não há dados de publicação deste episódio para afirmar qual versão terá melhor desempenho. A transferência pública do ZIP é verificada separadamente depois do empacotamento.
