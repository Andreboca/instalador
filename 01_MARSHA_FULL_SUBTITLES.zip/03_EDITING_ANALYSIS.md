# 03 — Análise da edição: Marsha e Clayton / VIRADA 1.0

Revisão final: fontes, montagem, legendas, mixagem e duas exportações concluídas. Os testes técnicos e a revisão visual dos quadros representativos das legendas passaram. A verificação da transferência pública pertence ao registro de entrega, realizado separadamente depois do empacotamento.

## Escopo e duração

Foram examinados os 23 vídeos novos desta entrega, na ordem 01 → 23. Os cinco textos de briefing são cópias idênticas. Cada exportação contém o mesmo episódio completo: A com todas as falas verificadas legendadas em inglês; B com uma seleção de falas importantes em inglês. Não há dublagem. A instrução mais recente do usuário manda preservar as vozes originais, incluindo o português efetivamente presente em 18.

| Métrica | Original recebido | Montagem aprovada |
|---|---:|---:|
| Duração de imagem | 176,833333 s / 02:56,833 | 150,958333 s / 02:30,958 |
| Quadros nativos | 4244 | 3623 |
| Cadência | 24 fps | 24 fps |
| Tempo retirado | — | 25,875 s, incluindo 7,958333 s da cópia 21 |

A ordem de todo conteúdo exclusivo foi preservada. O arquivo 21 é uma cópia byte a byte de 20; essa cena entra uma vez em 20. A redução restante vem de aberturas, sobras e reações redundantes, sem acelerar as falas ou inventar imagens. O relatório 04 apresenta todos os intervalos e motivos.

## Achados nas fontes

Todos os 23 arquivos foram identificados por SHA256, examinados com FFprobe e decodificados integralmente. Todos usam 24 fps. Vinte e dois têm 1080 × 1920; 07 tem 720 × 1280 e uma capa JPEG anexada. Somente o fluxo real H.264 de 07 entra na narrativa. Nenhuma fonte foi alterada.

A análise automática registrada não detectou preto ou congelamento indevido em 01–22 nos seus limiares. O fundo preto de 23 é intencional: texto branco centralizado CONTINUA... com brilho. A montagem utiliza os quadros 18 → 48, final exclusivo, correspondentes a 0,750 → 2,000 s da fonte. O cartão fica totalmente visível por 1,25 s.

A cena 07 contém bordas brancas móveis. O recorte 684 × 1216 em x18/y32 preserva 9:16 e foi conferido nos 241 quadros quanto às franjas laterais. A revisão visual dos quadros 0, 60, 120 e 240 preservou olhos, mãos, fotografia completa e abraço ao peito. O resultado é ampliado com Lanczos; isso não cria detalhe nativo 1080p.

As fontes 01–06 e 08–23 indicam matriz SMPTE170M, transferência sRGB e primárias BT709. A exportação converte efetivamente matriz e transferência para BT709. A fonte 07 já indica BT709; não basta apenas trocar a etiqueta de cor.

Os níveis narrativos originais variam aproximadamente de −25,89 a −9,63 LUFS. A fonte 07 é muito mais alta; 18 chega a +0,04 dBTP. Isso justifica correspondência de nível por clipe e espaço para picos. As pequenas caudas AAC após o último quadro precisam ser preservadas quando audíveis, sem cortar fala ou respiração.

## Revisão do ritmo e da narrativa

| Intervalo de saída | Conteúdo verificável e decisão |
|---|---|
| 00:00–00:03 | Ação ao vivo e acusação sobre dinheiro/comida dos filhos desde o começo; sem abertura gráfica ou antecipação de outra cena. |
| 00:03–00:08 | Rejeição de Clayton e afirmação de não ter dinheiro; manter as respostas inteiras. |
| 00:08–00:15 | Contradição sobre dinheiro para cerveja e comando agressivo. A repetição falada existe na interpretação e foi mantida. |
| 00:15–00:30 | A fome das crianças e o pedido para alimentá-las reforçam a consequência; encurtar as sobras depois das respostas. |
| 00:30–00:45 | Abandono, apelo e oração; preservar choro e pausas necessários para compreender a emoção. |
| 00:45–01:39,750 | Fotografia dos filhos, decisão, saída, procura por trabalho e oferta de ajuda; manter gestos e entrega do cartão completos. |
| 01:39,750–02:09,292 | Ostentação no bar e confronto de Jessica; manter a interpretação e as vozes originais. |
| 02:09,292–02:29,708 | Relato à mãe, cartão DINER, fim do apoio financeiro, expulsão e reação final. |
| 02:29,708–02:30,958 | Cartão CONTINUA... original, sem novas palavras. |

A montagem usa cortes diretos motivados. As fontes já contêm planos abertos, closes e reações. Não foram adicionados zooms aleatórios, flashes, distorções ou quadros artificiais. A velocidade permanece 1,0× em toda a narrativa.

## Som, legendas e limites

A trilha original foi composta e arranjada para este projeto com seis tratamentos emocionais. O AAC comum mede −18,86 LUFS e −1,70 dBTP; a dinâmica foi preservada sem comprimir ou limitar as vozes para forçar a referência nominal de −16 LUFS. O relatório 05 registra tempos, automação, licença e medidas reais. As legendas derivam das falas verificadas, com tempos convertidos uma única vez do relógio de cada fonte para a montagem. A possui 52 páginas; B possui 16 páginas para 15 falas selecionadas. O relatório 06 detalha o tratamento e a comparação mensurável.

O trecho 18 preserva o português original e recebe tradução fiel para inglês. A fonte 23 não contém fala validada: uma falsa hipótese do reconhecimento automático foi descartada.

Há mudanças de roupa já incorporadas à imagem: Clayton aparece sem camisa no primeiro plano de 01 e de regata nos seguintes; 17 também tem diferenças em relação a 16/18. Não foram inventadas imagens, alterados rostos ou roupas para disfarçar essas descontinuidades.

A recodificação H.264 e a ampliação de 07 impedem uma promessa matemática de ausência de perdas. Os originais são preservados. Os resultados reais de exportação, legibilidade, áudio e comparação A/B estão registrados abaixo. Nenhuma edição ou estratégia de legenda garante viralização, alcance ou aumento de retenção.

## Exportações e controle de qualidade executados

| Arquivo | Tamanho do MP4 | Imagem | Áudio |
|---|---:|---|---|
| `01_MARSHA_FULL_SUBTITLES.mp4` | 94.175.844 bytes | 1080 × 1920, 24 fps, H.264, BT709; 3623 quadros | AAC estéreo, 48 kHz; 150,958333 s |
| `02_MARSHA_SELECTIVE_SUBTITLES.mp4` | 94.168.874 bytes | Mesmo plano de imagem, duração, resolução e cadência | Todos os 7078 pacotes AAC iguais aos de A e à mixagem aprovada |

Ambos os filmes foram decodificados integralmente. Não foram encontrados intervalos pretos indevidos nem congelamentos narrativos inesperados nos testes registrados. O único intervalo congelado detectado, aproximadamente 02:29,708–02:30,917, pertence ao cartão final original e foi tratado como intencional.

A codificação de vídeo foi feita diretamente dos originais, uma geração H.264, CRF 18/preset slow com teto VBV de 4.800 kb/s para viabilizar o ZIP de download. A correção do relógio do contêiner para 48 kHz foi feita por cópia de streams: os 3623 pacotes de vídeo e seus tempos foram preservados, sem recodificação adicional. O AAC aprovado foi incorporado sem nova codificação; os 7078 pacotes, payloads e tempos passaram na comparação integral. A duração de áudio corresponde exatamente a 7.246.000 amostras por canal.

Foram inspecionados os 68 quadros representativos das páginas de legenda realmente codificadas: 52 de A e 16 de B, reunidos em oito pranchas. A legibilidade e a posição em relação a rostos e objetos importantes foram aprovadas nessas amostras. A abertura real e o cartão CONTINUA... foram conferidos. Essa revisão por página não é uma alegação de inspeção visual humana de todos os quadros do episódio.

Seis quadros de A, incluindo rostos e a cena 07, foram comparados com referências dos originais após a mesma conversão de cor/recorte. Os detalhes de rosto foram inspecionados em escala 1:1. O SSIM medido na região superior sem legendas variou de 0,980555 a 0,990481, média 0,986618. Esses valores descrevem apenas as seis amostras de A. Pequenas diferenças de textura são esperadas; não houve defeito material observado nessas amostras. Isso não certifica ausência matemática de perdas nem substitui análise de todos os quadros.

A comparação A/B confirmou o mesmo plano narrativo, grafo de imagem, número de quadros, duração e áudio. As diferenças planejadas são a seleção, o tamanho e os ajustes pontuais de posição das legendas. As conclusões sobre áudio usam integridade do PCM, cobertura de falas, medição do AAC e relação de nível voz/trilha; não incluem alegação de audição humana integral.

SHA256 dos arquivos finais:

- A: `cdfab2a10e0f83eafd88748e56fa005c7c09cbe8b33f71f4c0e283f81a09b45b`.
- B: `f7d777431bec1e9f4a2a6313aa1227edb9c1e4b6b627dff2e79529c80ac3ecab`.

Os quatro relatórios acompanham cada ZIP. O teste de download público completo, CRC do ZIP e hashes internos é registrado depois da publicação, fora destes relatórios, para evitar uma dependência circular de hashes no próprio pacote.
