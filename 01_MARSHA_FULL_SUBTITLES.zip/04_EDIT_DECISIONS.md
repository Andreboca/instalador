# 04 — Decisões de montagem

Projeto: Marsha e Clayton / VIRADA 1.0. EDL aprovada: 3623 quadros a 24 fps, 150,958333 s. A e B compartilham narrativa, cortes, cadência e áudio; somente as legendas mudam.

Os tempos abaixo usam minutos:segundos.milissegundos, arredondados para apresentação. Os quadros são a referência exata a 24 fps: o início está incluído e o fim é exclusivo. Os tempos de fonte reiniciam em cada arquivo. Os tempos de saída pertencem ao episódio único.

|Fonte|Intervalo mantido na fonte|Quadros mantidos|Intervalo na saída|Retirado da fonte|Motivo|
|---|---|---|---|---:|---|
|01|00:00.000–00:07.958|0→191|00:00.000–00:07.958|0.000 s|A acusação começa no primeiro instante; preservar todas as palavras.|
|02|00:00.000–00:07.958|0→191|00:07.958–00:15.917|0.000 s|Manter a troca completa e a acusação repetida realmente interpretada.|
|03|00:00.000–00:07.000|0→168|00:15.917–00:22.917|0.958 s|Encurtar a sobra depois da fala e da reação completa.|
|04|00:00.000–00:07.333|0→176|00:22.917–00:30.250|0.625 s|Encurtar a cauda depois da resposta e da respiração.|
|05|00:00.000–00:07.958|0→191|00:30.250–00:38.208|0.000 s|Preservar o abandono e o apelo final, que ocorre tarde.|
|06|00:00.000–00:07.000|0→168|00:38.208–00:45.208|0.958 s|Encurtar a sobra depois da oração e da reação.|
|07|00:01.500–00:10.042|36→241|00:45.208–00:53.750|1.500 s|Encurtar o choro repetido antes da primeira fala; preservar fotografia, mãos e decisão.|
|08|00:00.000–00:07.958|0→191|00:53.750–01:01.708|0.000 s|Preservar a decisão e o gesto tardio do punho erguido.|
|09|00:00.000–00:07.000|0→168|01:01.708–01:08.708|0.958 s|Encerrar somente depois de a bolsa estar totalmente no ombro.|
|10|00:02.000–00:07.958|48→191|01:08.708–01:14.667|2.000 s|Começar no plano aberto da porta; preservar saída, caminhada e fala.|
|11|00:01.958–00:07.958|47→191|01:14.667–01:20.667|1.958 s|Começar com a mão na porta do restaurante; preservar entrada e pedido de emprego.|
|12|00:01.000–00:07.083|24→170|01:20.667–01:26.750|1.875 s|Encurtar espera inicial e sobra; manter a última súplica e 26 quadros da reação da senhora.|
|13|00:01.958–00:07.958|47→191|01:26.750–01:32.750|1.958 s|Começar na aproximação da senhora; preservar a conversa e a ponte para a oferta.|
|14|00:00.000–00:07.000|0→168|01:32.750–01:39.750|0.958 s|Encerrar depois da entrega do cartão, já junto ao peito.|
|15|00:00.000–00:06.667|0→160|01:39.750–01:46.417|0.000 s|Preservar a ostentação, a pergunta do companheiro e a risada natural.|
|16|00:01.000–00:07.958|24→191|01:46.417–01:53.375|1.000 s|Encurtar a aproximação inicial; manter confronto e movimento de levantar completos.|
|17|00:00.000–00:07.958|0→191|01:53.375–02:01.333|0.000 s|Preservar a frase repetida realmente pronunciada e a intervenção final.|
|18|00:00.000–00:07.958|0→191|02:01.333–02:09.292|0.000 s|Preservar todas as vozes originais, inclusive o português, e o plano aberto final.|
|19|00:00.000–00:05.875|0→141|02:09.292–02:15.167|0.000 s|Preservar o relato completo e a revelação tardia do cartão DINER.|
|20|00:00.500–00:07.083|12→170|02:15.167–02:21.750|1.375 s|Encurtar abertura parada e sobra; manter a recusa e 26 quadros do plano aberto final.|
|21|00:00.000–00:07.958 (omitido)|—|Conteúdo já presente em 20|7.958 s|Arquivo byte a byte idêntico a 20; nenhuma fala exclusiva foi retirada.|
|22|00:00.000–00:07.958|0→191|02:21.750–02:29.708|0.000 s|Preservar a expulsão e a reação final com três personagens.|
|23|00:00.750–00:02.000|18→48|02:29.708–02:30.958|1.792 s|Preservar o cartão CONTINUA... já legível por 1,25 s; retirar a entrada lenta e a sobra.|

Total retirado: 621 quadros / 25,875 s. Desse total, 191 quadros / 7,958333 s são a cópia exata 21; os demais 430 quadros / 17,916667 s resultam dos encurtamentos descritos.

## Decisões transversais

- Preservar todas as falas e ações exclusivas significativas. A cópia integral 21 não acrescenta material exclusivo. A acusação repetida em 02 e o comando repetido em 17 são performances reais e permanecem.
- Manter velocidade 1,0× e 24 fps nativos, sem interpolação, dublagem ou alteração de tom das vozes.
- Usar cortes diretos para conversas e confrontos. As mudanças musicais usam transições suaves; não é necessário aplicar uma dissolução visual a cada corte.
- Preservar gestos e reações: punho erguido em 08, bolsa no ombro em 09, entrada em 11, entrega do cartão em 14, movimento de levantar em 16, cartão DINER em 19 e plano final com três personagens em 22.
- Recortar somente 07 em 684 × 1216, x18/y32, para remover as bordas brancas verificadas; ampliar para 1080 × 1920 sem esticar a proporção.
- Converter efetivamente os espaços de cor das fontes para BT709. Evitar escurecimento que esconda rostos ou zoom adicional sem necessidade.
- Usar somente os quadros originais do cartão 23. Não traduzir CONTINUA... nem adicionar texto ao encerramento.
- Preservar o português original de 18, conforme a instrução mais recente do usuário; traduzir apenas as legendas para inglês.

## Verificabilidade e limites

Os hashes das 23 fontes constam do inventário técnico. 20 e 21 têm o mesmo SHA256: `c3c48187832ca93172455a797042cef529c2b194f68a51699fea7acf9965ebee`. A EDL guarda os limites exatos e o hash da fonte de cada região.

As escolhas de borda em 12 e 20 preservam 26 quadros, aproximadamente 1,083 s, da última tomada nativa, evitando uma mudança de plano de apenas um ou dois quadros. O recorte de 07 foi comparado visualmente nos quadros 0, 60, 120 e 240 e medido em todos os 241 quadros da fonte.

As descontinuidades de figurino já existentes em 01 e 17 continuam visíveis. Não há correção artificial de pessoas, roupas ou acontecimentos. A EDL foi executada nos dois MP4s e confrontada com os arquivos finais. Ambos têm 3623 quadros, 150,958333 s, 1080 × 1920 e 24 fps. A decodificação integral passou; a comparação A/B confirmou o mesmo plano de imagem e todos os 7078 pacotes AAC idênticos. A única pausa visual classificada como congelamento pertence ao cartão final original. A revisão visual de um quadro de cada uma das 68 páginas de legenda passou; a abertura e o cartão final também foram conferidos. Os limites da revisão e os hashes dos MP4s estão no relatório 03.
