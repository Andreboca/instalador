# 05 — Cue sheet da trilha e da mixagem

Projeto: Marsha e Clayton / VIRADA 1.0. Os seis módulos instrumentais foram compostos para esta edição. Não foi reutilizada a música Luminous Resolution, a trilha de Claire, uma canção comercial ou trilha de filme.

A mixagem comum A/B foi executada e seu AAC foi medido. Os dois MP4s finais foram decodificados e tiveram todos os pacotes de áudio comparados com essa mixagem. Duração do áudio: 150,958333 s, exatamente 7.246.000 amostras de apresentação por canal a 48 kHz, sincronizadas com os 3623 quadros a 24 fps.

## Posicionamento executado

Os tempos usam minutos:segundos.milissegundos, arredondados para apresentação. Os limites exatos constam do manifesto de arranjo. Os módulos se sobrepõem apenas nas transições indicadas; não reiniciam a cada arquivo.

| Módulo original | Intervalo na saída | Trecho usado do módulo | Fade de entrada / saída | Função narrativa |
|---|---|---|---|---|
| `01_injustice_tension` | 00:00.000–00:45.808 | 00:00.000–00:45.808 | 0.45 s / 0.60 s | Discussão por dinheiro, fome dos filhos e abandono: piano/cordas baixas com tensão contida. |
| `02_sadness_piano` | 00:45.208–01:15.267 | 00:00.000–00:30.058 | 0.60 s / 0.60 s | Fotografia, vulnerabilidade e decisão de seguir pelos filhos: piano esparso. |
| `03_hope_opportunity` | 01:14.667–01:40.350 | 00:00.000–00:25.683 | 0.60 s / 0.60 s | Busca por trabalho e oferta de ajuda: calor moderado de piano e cordas. |
| `04_confrontation_pulse` | 01:39.750–02:09.892 | 00:00.000–00:30.142 | 0.60 s / 0.60 s | Ostentação no bar e confronto de Jessica: pulso baixo e suspense discreto. |
| `05_decision_resolve` | 02:09.292–02:20.558 | 00:00.000–00:11.267 | 0.60 s / 0.60 s | Relato à mãe e corte do apoio financeiro: força contida. |
| `06_cliffhanger_unresolved` | 02:19.958–02:30.958 | 00:08.000–00:19.000 | 0.60 s / 0.00 s | Última decisão, expulsão, reação e cartão: harmonia suspensa com cauda natural. |

As mudanças de tratamento usam crossfades de 0,6 s. O primeiro módulo entra em 0,45 s, sem introdução que atrase a imagem ou a fala. O último utiliza o trecho 8–19 s do módulo original e termina com sua própria cauda natural; não há fade abrupto imposto ao final. O acorde suspenso desse trecho acompanha a decisão final e conduz ao cartão existente `CONTINUA...`. Não foram adicionados impactos, whooshes ou novos efeitos decorativos.

## Automação e preservação das vozes

A música usa ganho de −17 dB em relação aos arquivos dos módulos durante fala/VAD e −8 dB entre falas, antes do ganho comum final. Isso é uma redução de 9 dB da música ao entrar fala, não uma alegação de relação fixa de volume entre música e voz. A automação emprega antecipação de 100 ms, proteção de saída de 220 ms e suavização de 50 ms.

A medição de 327 janelas de 200 ms em intervalos de fala encontrou a voz 17,26 dB acima da música na mediana; o percentil 10 foi 10,18 dB. É uma relação de níveis medida, não uma garantia de inteligibilidade ou retenção para todos os ouvintes e aparelhos.

As vozes mantêm velocidade, tom e timbre originais. O tratamento de diálogo consiste em ganho estático por fonte, calculado com base nos trechos ativos, mais ganho comum final de +1,18 dB. Por exemplo, 07 recebe −8,82 dB e 18 recebe −5,65 dB antes desse ganho comum. Não foram aplicados equalização, redução de ruído, compressão, limitador, alteração de pitch, time-stretch ou dublagem. Pequenos fades de 5 ms ocorrem apenas em bordas cortadas sem voz.

As caudas nativas AAC depois do último quadro mantido são carregadas para o início quieto da tomada seguinte. Isso inclui os 976 samples / 20,333 ms de 13 no início de 14. As regiões interiores do diálogo montado em float foram comparadas ao PCM original multiplicado pelo ganho estático, com resíduo zero. Essa prova se refere à montagem anterior à codificação AAC; não afirma identidade matemática do AAC lossy com o PCM.

O português de 18 permanece no áudio original. O tag de idioma é `mul`, coerente com as vozes mistas reais. A cópia exata 21 é omitida, e as falas exclusivas dos demais arquivos permanecem dentro dos limites mantidos.

## Medição do arquivo AAC real

| Medida | Resultado |
|---|---:|
| Formato | AAC estéreo, 48 kHz, 192 kb/s |
| Duração de apresentação | 150,958333 s |
| Loudness integrada | −18,86 LUFS |
| Pico verdadeiro | −1,70 dBTP |
| LRA | 7,90 LU |
| Teto de pico verificado | Abaixo de −1,00 dBTP |

A loudness ficou abaixo da referência inicial de −16 LUFS para preservar transientes e dinâmica sem limitar ou comprimir as vozes. A medição usa o AAC efetivamente exportado; os campos de saída simulada do medidor não representam processamento aplicado ao arquivo. A e B receberam exatamente essa mesma trilha AAC, copiada sem uma nova codificação de áudio. Os 7078 pacotes de áudio de cada MP4 mantêm payloads e tempos idênticos aos da mixagem aprovada; a comparação A/B passou.

SHA256 do AAC comum: `8da65d5093fb0e7a50be72b052967c441bac29f21dd7db1876d29ea06e4d0155`.

## Composição, instrumentos e licença

A composição utiliza piano, cordas, violoncelo e pizzicato, renderizados offline pelo FluidSynth 2.4.4 com GeneralUser GS v2.0.3, do mantenedor S. Christian Collins. As notas, voicings, tempos e dinâmicas foram gerados para o projeto. A trilha não contém vozes ou narração adicional.

A licença publicada do instrumento permite explicitamente criação musical privada ou comercial e lucro com gravações produzidas. A comprovação local inclui a licença integral, o manifesto de procedência e o arquivo de notas. Essa permissão não equivale a uma auditoria independente da titularidade de cada amostra nem a uma garantia de ausência de reivindicações automáticas de plataforma.

- Instrumento SHA256: `9575028c7a1f589f5770fccc8cff2734566af40cd26ed836944e9a5152688cfe`.
- Licença SHA256: `7b32efefdf95ce38a043799f0659853ddc00fbaa14d8c50f0aca16b9b8b405be`.
- Partitura de notas SHA256: `68e6121d569a371a5c6f9606d8a3e5b077f1c071de64b1e834c9de121858e5a2`.
- Origem do instrumento: https://raw.githubusercontent.com/mrbumpy409/GeneralUser-GS/main/GeneralUser-GS.sf2.

Os originais, a montagem de diálogo, a trilha instrumental e o master float da mixagem foram preservados. As provas locais incluem o manifesto de arranjo, a validação do AAC final, a montagem de diálogo e a verificação de integridade da forma de onda. Nenhuma medição de áudio garante alcance ou engajamento do vídeo.

## Escopo do controle final

A decodificação integral dos dois MP4s e as medidas de loudness/pico passaram. A preservação da fala é sustentada pela comparação de PCM antes da codificação e pela cobertura dos limites de palavras/caudas; a equivalência do áudio entregue é sustentada pela comparação de todos os pacotes AAC. As medidas de relação voz/trilha não constituem uma audição humana integral nem uma garantia para todos os sistemas de reprodução. O controle de transferência dos ZIPs é registrado separadamente após a publicação.
