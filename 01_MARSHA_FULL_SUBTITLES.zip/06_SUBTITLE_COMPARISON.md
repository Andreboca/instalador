# 06 — Comparação de legendas

Projeto: Marsha e Clayton / VIRADA 1.0. As versões A e B apresentam o mesmo episódio completo de 150,958333 s, a 24 fps, com as vozes originais. Esta comparação trata do uso das legendas. A compilação, a revisão de posicionamentos críticos e a inspeção dos quadros representativos das páginas nos MP4s finais foram concluídas.

| Característica | A — Full subtitles | B — Selective subtitles |
|---|---|---|
| Texto | Todas as falas inteligíveis verificadas. | Somente falas reais de acusação, decisão, ameaça ou virada importante. |
| Idioma | Inglês. | Inglês. |
| Vozes | Originais, incluindo o português de 18. | Exatamente o mesmo áudio de A. |
| Fonte compilada | Montserrat ExtraBold, 84 unidades na composição 1080 × 1920. | A mesma família, 96 unidades; frases longas divididas sem reduzir a fonte. |
| Apresentação | Uma ou duas linhas, branco, contorno/sombra escura, poucos destaques dourados. | Uma ou duas linhas com o mesmo contraste, menos tempo total de texto na tela. |
| Páginas | 52 | 16, correspondentes a 15 falas selecionadas. |
| Tempo total programado com legendas | 78,804 s / 52,20% do episódio. | 24,696 s / 16,36% do episódio. |
| Largura máxima medida de linha | 729,89 px | 705,69 px |
| Limite de largura adotado | 760 px | 760 px |
| Posição principal | Inferior central segura, x540/y1545. | A mesma região segura, x540/y1545. |
| Diferencial a testar | Compreensão de todas as frases, inclusive em reprodução sem som. | Maior presença visual das falas decisivas e mais intervalos sem texto. |

O tempo total acima soma os intervalos programados, sem sobreposição entre páginas. Ele descreve a composição; não mede atenção, retenção ou desempenho de publicação. A entrada do texto é discreta: aproximadamente 80 ms de 96% a 100% de escala, sem saltos repetidos.

## Fidelidade e sincronização

A transcrição é vinculada às fontes reais e aos índices das palavras. A conversão para o relógio final aplica o início de cada trecho e o deslocamento da montagem uma única vez. A revisão de cobertura relaciona 277 índices lexicais das fontes mantidas, sem duplicação. A risada não verbal de 15 continua no áudio, sem ser transformada em fala escrita fictícia.

A checagem dos 68 eventos ASS compilados encontrou arredondamento máximo de 5 ms para centésimos de segundo, sem sobreposição ou saída dos intervalos mantidos da EDL. Algumas páginas cobrem de 0 a 388 ms de cauda medida de voz/VAD depois do último lexema do ASR; isso acompanha o decaimento detectado, sem acrescentar uma permanência arbitrária para leitura. Essa precisão do evento ASS não implica resolução temporal maior que o quadro de vídeo a 24 fps.

As falas repetidas de 02 e 17 permanecem onde são realmente pronunciadas. A cópia integral 21 é excluída das duas versões junto com sua duplicação de áudio/imagem. Na fonte 05, a análise de pequenos recortes corrigiu o início de “I'm leaving.” para aproximadamente 4,01–4,80 s da fonte, em vez de exibir a frase durante uma pausa anterior. A fonte 23 não recebeu legenda de fala: a hipótese automática de linguagem em um cartão sem fala foi rejeitada.

A fonte 18 contém as vozes portuguesas originais. A instrução mais recente do usuário determinou preservá-las. As legendas em inglês traduzem fielmente:

- “Minha mãe não vai mais bancar suas despesas!” → “My mom won't pay your bills anymore!”
- “Não se mete, garota!” → “Stay out of it, girl!”

Não foram inseridas frases de exemplo do briefing quando não pronunciadas. A seleção B contém “The kids have nothing to eat.”, “But you got money for beer.”, “Our kids are starving.”, “You're on your own.”, “I'm not giving up on you.”, “I'm gonna fight for my kids.”, “I'm sorry, we're not hiring.”, “Yes, ma'am. I'll do anything.”, “I can help.”, “Marsha's gonna keep paying my bills.”, a acusação de Jessica em 16, a decisão de 18, o relato de 19, a recusa de 20 e “Get out of my house, Clayton!”.

## Ajustes de legibilidade e posicionamento

A acusação longa de 16 na versão B foi dividida no limite real da palavra em 2,94 s da fonte: “My mom's suffering” / “and you're out here drinking?”. As duas páginas conservam o texto completo, a fonte 96 e no máximo duas linhas.

Três páginas de A receberam ajuste vertical após revisão do quadro real com ASS: 08-02 usa y1300 para ficar abaixo da boca e acima de caderno/mãos no close; 14-02 e 14-03 usam y1400 para preservar o cartão e sua entrega. As demais usam y1545. Nenhuma legenda fica no topo. A revisão de amostras críticas não encontrou obstrução de rosto. A conferência posterior de um quadro representativo de cada uma das 52 páginas de A e 16 de B nos MP4s finais aprovou a leitura e o posicionamento. Essa revisão por página não afirma inspeção humana de todos os quadros durante todos os movimentos.

## Comparação e limites

A comparação executada confirmou o mesmo plano narrativo, duração de 150,958333 s, 3623 quadros, resolução e cadência nas duas exportações. Os 7078 pacotes AAC, inclusive seus payloads e tempos, são idênticos entre A, B e a mixagem aprovada. A decodificação integral passou nas duas versões. A aprovação técnica automatizada foi complementada pela revisão visual dos 68 quadros representativos, um por página de legenda, além da abertura e do cartão final. O download público é verificado separadamente após empacotamento e publicação.

Nenhum estilo é apresentado como “o que mais viraliza”. Não há dados de alcance, retenção ou teste A/B real deste episódio. Comparar as versões exige resultados de publicação obtidos nas mesmas condições; o trabalho de edição não garante melhor desempenho de B ou de A.
